// Toggle navbar (responsive)
const toggleBtn = document.querySelector('.toggle-btn');
const navLinks = document.querySelector('.nav-links');

toggleBtn.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

// Interaksi tombol
const tombol = document.getElementById("tombolKlik");

tombol.addEventListener("click", function () {
  alert("Halo Salsa! Kamu barusan ngeklik tombol ✨");
});